import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { CozeAPI, COZE_COM_BASE_URL, ChatStatus, RoleType } from '@coze/api';
import dotenv from 'dotenv';
dotenv.config();

const ChatComponent: React.FC = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{content: string | File; isAI: boolean; preview?: string}>>([]);
const [uploading, setUploading] = useState(false);
  const client = new CozeAPI({
    token: import.meta.env.VITE_COZE_PAT,
    baseURL: COZE_COM_BASE_URL,
  });
  const messageEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
  if (!e.target.files?.[0]) return;
  const file = e.target.files[0];
  setUploading(true);
  
  const reader = new FileReader();
  reader.onloadend = () => {
    setMessages(prev => [...prev, { 
      content: file, 
      isAI: false,
      preview: file.type.startsWith('image/') ? reader.result as string : undefined
    }]);
    setUploading(false);
  };
  reader.readAsDataURL(file);
};

const handleSend = async () => {
    if (!input.trim()) return;

    const message = input.trim();
    setMessages(prevMessages => [...prevMessages, { content: message, isAI: false }]);

    setInput('');
    try {
      let fullResponse = '';
const stream = await client.chat.createAndStream({
        bot_id: import.meta.env.VITE_COZE_BOT_ID,
        files: messages
  .filter((m): m is File => m instanceof File)
  .map(file => ({ content: URL.createObjectURL(file), content_type: file.type })),
additional_messages: [{
          role: RoleType.User,
          content: message,
          content_type: 'text',
        }],
      });

      for await (const chunk of stream) {
  if (chunk.content) {
    fullResponse += chunk.content;
    setMessages(prevMessages => {
      const newMessages = [...prevMessages];
      const lastMessageIndex = newMessages.findIndex(m => !m.isAI);
      if (lastMessageIndex > -1) {
        newMessages[lastMessageIndex] = { content: fullResponse, isAI: true, preview: undefined };
      }
      return newMessages;
    });
  }
}
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const renderMessage = (message: string) => {
    if (message.startsWith('```')) {
      return (
        <pre>
          <code>{message}</code>
        </pre>
      );
    }
    return (
  <ReactMarkdown
    remarkPlugins={[remarkGfm]}
    components={{
      code({node, inline, className, children, ...props}) {
        return (
          <div className="code-block">
            <button 
              className="copy-button"
              onClick={() => navigator.clipboard.writeText(String(children))}
            >
              Copy
            </button>
            <code {...props}>
              {children}
            </code>
          </div>
        );
      }
    }}
  >
    {message}
  </ReactMarkdown>
);
  };

  return (
    <div className="chat-container">
      <input
        type="file"
        accept="image/*,.pdf"
        onChange={handleFileUpload}
        disabled={uploading}
        style={{display: 'none'}}
        id="fileUpload"
      />
      <label htmlFor="fileUpload" className="file-upload-button">
        {uploading ? '上传中...' : '上传文件'}
      </label>
      <input
        type="text"
        value={input}
        onChange={handleInputChange}
        onKeyPress={e => e.key === 'Enter' && handleSend()}
        placeholder="Type your message..."
        className="chat-input"
      />
      <button onClick={handleSend} className="chat-send-button">Send</button>
      <div className="chat-messages">
        {messages.map((message, index) => (
          <div key={index} className="chat-message">
            {message.content instanceof File ? (
              message.content.type === 'application/pdf' ? (
                <div className="pdf-preview">
                  <span>PDF文件: {message.content.name}</span>
                </div>
              ) : message.preview ? (
                <img 
                  src={message.preview} 
                  alt="上传预览"
                  className="image-preview"
                />
              ) : null
            ) : renderMessage(message.content)}
          </div>
        ))}
        <div ref={messageEndRef}></div>
      </div>
    </div>
  );
};

export default ChatComponent;