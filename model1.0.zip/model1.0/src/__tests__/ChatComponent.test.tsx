import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import ChatComponent from '../ChatComponent';

describe('ChatComponent 核心功能测试', () => {
  test('多媒体上传验证', async () => {
    const file = new File(['test content'], 'test.png', { type: 'image/png' });
    render(<ChatComponent />);
    
    const input = screen.getByLabelText(/上传文件/i);
    fireEvent.change(input, { target: { files: [file] } });

    await waitFor(() => {
      expect(screen.getByText('test.png')).toBeInTheDocument();
      expect(screen.getByText(/上传成功/i)).toBeInTheDocument();
    });
  });

  test('流式响应展示', async () => {
    const mockStreamResponse = jest.fn(() => 
      new Response(new ReadableStream({
        start(controller) {
          controller.enqueue(new TextEncoder().encode('流式数据块1'));
          controller.enqueue(new TextEncoder().encode('流式数据块2'));
          controller.close();
        }
      }))
    );

    global.fetch = mockStreamResponse;
    render(<ChatComponent />);

    fireEvent.click(screen.getByRole('button', { name: /发送/i }));

    await waitFor(() => {
      expect(screen.getByText('流式数据块1流式数据块2')).toBeInTheDocument();
    });
  });

  test('Markdown渲染验证', async () => {
    const testMarkdown = '# 标题
**加粗文字**';
    render(<ChatComponent initialMessage={testMarkdown} />);

    expect(screen.getByRole('heading', { name: '标题' })).toBeInTheDocument();
    expect(screen.getByText('加粗文字').closest('strong')).toBeInTheDocument();
  });
});