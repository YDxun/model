import React from 'react';
import './App.css';
import ChatComponent from './ChatComponent';

const App: React.FC = () => {
  return (
    <div className="App">
      <h1>LLM Chat</h1>
      <ChatComponent />
    </div>
  );
};

export default App;