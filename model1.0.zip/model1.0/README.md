# LLM Chat

This is a simple LLM chat application built with React, Vite, and TypeScript. It uses the `@coze/api` library to interact with a large language model.

## Features

- User input with support for images, PDFs, and other multimedia formats
- Real-time streaming of LLM responses
- Support for text, Markdown, and images in LLM responses
- Copy code blocks from LLM responses

## Installation

```bash
npm install