export interface Message {
  id: string;
  content: string | File;
  isAI: boolean;
  timestamp: number;
  contentType: 'text' | 'image' | 'file' | 'markdown';
}

export interface ChatConfig {
  apiKey: string;
  maxTokens: number;
  temperature: number;
  stream: boolean;
}