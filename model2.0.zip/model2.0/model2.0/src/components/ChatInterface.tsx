import { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message } from '../types';

interface ChatInterfaceProps {
  config: {
    apiKey: string;
    maxTokens: number;
    temperature: number;
  };
}

export function ChatInterface({ config }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: input,
      isAI: false,
      timestamp: Date.now(),
      contentType: 'text',
    };

    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setIsLoading(true);

    try {
    const response = await fetch('https://api.coze.com/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        message: input,
        stream: true,
        max_tokens: config.maxTokens,
        temperature: config.temperature
      })
    });

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let aiMessage: Message = {
      id: Date.now().toString(),
      content: '',
      isAI: true,
      timestamp: Date.now(),
      contentType: 'text'
    };

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        aiMessage.content += chunk;
        
        // 更新消息内容
        setMessages(prev => {
          const index = prev.findIndex(m => m.id === aiMessage.id);
          if (index === -1) return [...prev, aiMessage];
          const newMessages = [...prev];
          newMessages[index] = { ...aiMessage };
          return newMessages;
        });
      }
    }
  } catch (error) {
    console.error('API调用失败:', error);
  } finally {
    setIsLoading(false);
  }
  };

  return (
    <div className="chat-container">
      <div className="messages-area">
        {messages.map((message) => (
          <div key={message.id} className={`message ${message.isAI ? 'ai' : 'user'}`}>
            {message.contentType === 'markdown' ? (
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {message.content.toString()}
              </ReactMarkdown>
            ) : (
              <div className="content">
            {message.contentType === 'image' && (
              <img 
                src={URL.createObjectURL(message.content as File)}
                alt="上传的图片"
                style={{ maxWidth: '300px' }}
              />
            )}
            {message.contentType === 'file' && (
              <a 
                href={URL.createObjectURL(message.content as File)}
                download
              >
                下载文件
              </a>
            )}
            {message.contentType === 'text' && message.content.toString()}
            
            {message.contentType === 'markdown' && (
              <ReactMarkdown
                components={{
                  code({ node, inline, className, children, ...props }) {
                    return (
                      <div className="code-block">
                        <button 
                          className="copy-button"
                          onClick={() => navigator.clipboard.writeText(String(children))}
                        >
                          复制
                        </button>
                        <code className={className} {...props}>
                          {children}
                        </code>
                      </div>
                    );
                  }
                }}
              >
                {message.content.toString()}
              </ReactMarkdown>
            )}
          </div>
            )}
          </div>
        ))}
        {isLoading && <div className="loading-indicator">思考中...</div>}
        <div ref={messagesEndRef} />
      </div>
      
      <form onSubmit={handleSubmit} className="input-area">
        <div className="input-group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="输入消息..."
          />
          <input
            type="file"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const newMessage: Message = {
                  id: Date.now().toString(),
                  content: file,
                  isAI: false,
                  timestamp: Date.now(),
                  contentType: file.type.startsWith('image/') ? 'image' : 'file'
                };
                setMessages(prev => [...prev, newMessage]);
              }
            }}
            accept="image/*,application/pdf"
            style={{ display: 'none' }}
            id="file-upload"
          />
          <label htmlFor="file-upload" className="upload-button">
            上传文件
          </label>
        </div>
        <button type="submit">发送</button>
      </form>
    </div>
  );
}